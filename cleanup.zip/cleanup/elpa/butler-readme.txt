Provides an interface to connect to the Jenkins CI server
