class RSTReport(object):
    pass
