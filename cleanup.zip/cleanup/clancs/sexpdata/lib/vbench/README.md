======================================================
vbench: performance benchmarking for your repo history
======================================================

Example usage
-------------

https://github.com/wesm/pandas/tree/master/vb_suite

Benchmarks: https://github.com/wesm/pandas/tree/master/vb_suite/reindex.py

Running the benchmarks
  - https://github.com/wesm/pandas/tree/master/vb_suite/suite.py
  - https://github.com/wesm/pandas/tree/master/vb_suite/run_suite.py